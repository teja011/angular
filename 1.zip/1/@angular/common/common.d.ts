/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { COMMON_DIRECTIVES as ɵa } from './src/directives/index';
export { COMMON_PIPES as ɵb } from './src/pipes/index';
